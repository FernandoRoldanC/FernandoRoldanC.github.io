clc; 
clear all;
close all;


%Original Image
z=imread('saturn.tif'); %128 pixels image
%z=imread('circular.tif'); %256 pixels image
z=double(z)./max(double(z(:)));
zz=z;

%% Blur
H=fspecial('gaussian',9,4);

%% Blur operator
[P,center]=psfGauss([9,9],4);
[m,n]=size(z);
Pbig=padPSF(P,[m,n]);

e1=zeros(m,n);
e1(1,1)=1;
Sbig=dct2(dctshift(Pbig,center))./dct2(e1);


%D = nabla d
trans=@(X)dct2(X);
itrans=@(X)idct2(X);
K =@(X) itrans( Sbig .* trans(X) ) ; 
KA=@(X) itrans( conj(Sbig .* trans(X) )) ; 

% Blurred image
b=K(zz);
% Noise
randn('seed',314);
b=imnoise(b,'gaussian',0,1e-3);
%
Kb = KA(b);
Sbig2 = Sbig.*Sbig;
D = @(X)  lam3*(KA(K(X))-Kb);

% Tolerance
tol = 1e-6;


%%parameters
lam1 = 1e-1; % Norm 1
lam2 = 1e-3; % Huber function
lam3 = 1; % Norm 2 (in the article is 1)
delta = 1e-2; %Huber function

% Lipshitz, cocercive and norm Constants
nL=sqrt(8);
zeta = lam2/delta;
beta = 1/(lam3*max(max(abs(Sbig).^2)));


% Haar basis level
wavlev = 3;


% step-sizes for Section 6.2
tau_FPDHF = 0.5;
tau_PDBTR = 0.5;

% step-sizes for Section 6.3, in this case delta must be changed to 1e-4
%tau_FPDHF = (-1/(2*beta)+sqrt(1/(4*beta^2)+4*zeta^2))/(2*zeta^2).*0.95;
%tau_PDBTR =  1/(2*zeta+1/(2*beta)).*0.95;



[time_FPDHF,SNR_FPDHF,fo_FPDHF,x_FPDHF,errorFPDHF,iter_FPDHF]=FPDHF(zz,Sbig,lam1,lam2,lam3,delta,b,tol,wavlev,tau_FPDHF);
[time_FBHFPD,SNR_FBHFPD,fo_FBHFPD,errorFBHFPD,iter_FBHFPD,x_FBHFPD]=FBHFPD(zz,Sbig,lam1,lam2,lam3,delta,b,tol,wavlev,tau_FPDHF,1);
[time_PDBTR,SNR_PDBTR,fo_PDBTR,errorPDBTR,iter_PDBTR,x_PDBTR]=PDBTR(zz,Sbig,lam1,lam2,lam3,delta,b,tol,wavlev,tau_PDBTR);
[time_PDRCK,SNR_PDRCK,fo_PDRCK,errorPDRCK,iter_PDRCK,x_PDRCK]=PDRCK(zz,Sbig,lam1,lam2,lam3,delta,b,tol,wavlev,tau_PDBTR);



T(1,1:3) = [iter_FPDHF time_FPDHF fo_FPDHF];
T(2,1:3) = [iter_FBHFPD time_FBHFPD fo_FBHFPD];
T(3,1:3) = [iter_PDBTR time_PDBTR fo_PDBTR];
T(4,1:3) = [iter_PDRCK time_PDRCK fo_PDRCK]
