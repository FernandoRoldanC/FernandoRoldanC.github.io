function     [time_PDBTR,SNR_PDBTR,fo_PDBTR,errorPDBTR,iter_PDBTR,x_PDBTR]=PDBTR(zz,Sbig,lam1,lam2,lam3,delta,b,tol,wavlev,t)
    
        [m,n]=size(zz);
    %Linear operator
    L=@(X)Ltransold(X);
    LT=@(P)Lforwardold(P);
    

    %D = nabla d
    trans=@(X)dct2(X);
    itrans=@(X)idct2(X);
    K =@(X) itrans( Sbig .* trans(X) ) ; 
    KA=@(X) itrans( conj(Sbig .* trans(X) )) ; 

    %
    Kb = KA(b);
    Sbig2 = Sbig.*Sbig;
    D = @(X)  lam3*(KA(K(X))-Kb);
    
    %C wavelets
    wav=@(X)wavelet('2D haar',wavlev,X);
    iwav=@(X)wavelet('2D haar',-wavlev,X);
    C = @(x) lam2*iwav(grad_Huber(wav(x),delta));

    nL=sqrt(8);
    zeta = lam2/delta;
    beta = 1/(lam3*max(max(abs(Sbig).^2)));


%%%%  
lamk = 2;
lamk_ = 2;

t1 = t;
s1 = 0.9999*(1-t1*(2*zeta+1/(2*beta)))/(t1*nL^2);
   if  s1<=0
    msg = 'invalid tau.';
    error(msg)
    end

t11=t1;
s11=s1;

x = b;
x_o = x;
c2x =  C(x);
u{1}=zeros(m-1,n);
u{2}=zeros(m,n-1);
z=u;
iter_PDBTR = 0;
error_it=1;
    tic
    % j = 1:niter
while error_it > tol;
    iter_PDBTR = iter_PDBTR+1;
    x_a = x_o;
    x_o = x;
    u_o = u;
    c2x_ = c2x;

    c2x = C(x_o);
    y_  = x_o-t1*(LT(u_o)+2*c2x-c2x_+D(x_o));
    x = min(max(0,y_),1);


    v = lamk*(x-x_o);

    vv = L(x_o+v);

    u1 = (u_o{1}+s1*vv{1})/s1;
    prox = sign(u1) .* max(0, abs(u1) - lam1/s1);
    u{1} = (u1-prox)*s1;

    u2 = (u_o{2}+s1*vv{2})/s1;
    prox = sign(u2) .* max(0, abs(u2) - lam1/s1);
    u{2} = (u2-prox)*s1;
    error_it= sqrt((norm(x-x_o,'fro')^2+norm(u{1}-u_o{1},'fro')^2+norm(u{2}-u_o{2},'fro')^2) /(norm(x_o,'fro')^2 + norm(u_o{1},'fro')^2+norm(u_o{2},'fro')^2));

end
time_PDBTR=toc;
SNR_PDBTR = - 20*log10(norm(zz - x,2)/norm(zz,2));
xxx = L(x);
fo_PDBTR = lam3*norm(K(x)-b,2)^2/2+lam1*sum(sum(abs(xxx{1})))+lam1*sum(sum(abs(xxx{2})))+huberf(wav(x),lam2,delta);
errorPDBTR= error_it;

x_PDBTR = x;