function     [time_FBHFPD,SNR_FBHFPD,fo_FBHFPD,errorFBHFPD,iter_FBHFPD,x_FBHFPD]=FBHFPD(zz,Sbig,lam1,lam2,lam3,delta,b,tol,wavlev,t,th)
    
        [m,n]=size(zz);
    %Linear operator
    L=@(X)Ltransold(X);
    LT=@(P)Lforwardold(P);
    

    %D = nabla d
    trans=@(X)dct2(X);
    itrans=@(X)idct2(X);
    K =@(X) itrans( Sbig .* trans(X) ) ; 
    KA=@(X) itrans( conj(Sbig .* trans(X) )) ; 

    %
    Kb = KA(b);
    Sbig2 = Sbig.*Sbig;
    D = @(X)  lam3*(KA(K(X))-Kb);
    
    %C wavelets
    wav=@(X)wavelet('2D haar',wavlev,X);
    iwav=@(X)wavelet('2D haar',-wavlev,X);
    C = @(x) lam2*iwav(grad_Huber(wav(x),delta));

    nL=sqrt(8);
    zeta = lam2/delta;
    beta = 1/(lam3*max(max(abs(Sbig).^2)));

    x = b;
    u{1}=zeros(m-1,n);
    u{2}=zeros(m,n-1);




% syms XX
% eqn = (zeta+(1-th)*nL/2)^2-(1/XX-(1+th)*nL/2)*(1/XX-(1+th)*nL/2-1/(2*beta)) == 0;
% gamma = vpasolve(eqn,XX);
% index = find(gamma == min(gamma(gamma>0)));
% gamma = gamma(index);
% clear XX


%t = 0.9*(-1/(2*beta)+sqrt(1/(4*beta^2)+4*zeta^2))/(2*zeta^2);

rhomin = 1/(4*beta)+sqrt(1/(16*beta^2)+(zeta+(1-th)*nL/2)^2);

syms XX
eqn =  (XX+t-sqrt((XX-t)^2+XX^2*t^2*(1+th)^2*nL^2))/(2*XX*t)-rhomin == 0;
s = vpasolve(eqn,XX);
if  isempty(s);
    msg = 'invalid tau.';
    error(msg)
end

index = find(s == min(s(s>0)));
s = s(index);
clear XX
s = 0.999*double(s);

% test rho-rhomin>0
%(s+t-sqrt((s-t)^2+s^2*t^2*(1+th)^2*nL^2))/(2*s*t)-rhomin;

%gamma = [gamma,1.99/((1+th)*nL)];
%t = double(min(gamma));

M = 1/min(t,s)+(1+th)*nL/2;
lambda = 0.99/M;
%s= t;

lam1s=lam1/s;
iter_FBHFPD = 0;
x = b;
u{1}=zeros(m-1,n);
u{2}=zeros(m,n-1);
    error_it=1;
    tic
    % j = 1:niter
while error_it > tol;
    iter_FBHFPD = iter_FBHFPD+1;
    x_o = x;
    u_o = u;

    c2x = C(x_o);
    y_  = x_o-t*(D(x_o)+c2x+LT(u_o));
    y = min(max(0,y_),1);

    vv = L(y+th*(y-x_o));

    v1 = (u_o{1}+s*vv{1})./s;
    prox = sign(v1) .* max(0, abs(v1) - lam1s);
    v_u{1} = (v1-prox)*s;

    v2 = (u_o{2}+s*vv{2})/s;
    prox = sign(v2) .* max(0, abs(v2) - lam1s);
    v_u{2} = (v2-prox)*s;

    uv{1} = u_o{1}-v_u{1};
    uv{2} = u_o{2}-v_u{2};
    x = x_o + lambda*(y-x_o+t*(c2x-C(y)+LT(uv)))./t;

    vv = L(y-x_o);
    u{1} = u_o{1} + lambda*(v_u{1}-u{1}-s*th*vv{1})./s;
    u{2} = u_o{2} + lambda*(v_u{2}-u{2}-s*th*vv{2})./s;
    error_it =  sqrt((norm(x-x_o,'fro')^2+norm(u{1}-u_o{1},'fro')^2+norm(u{2}-u_o{2},'fro')^2) /(norm(x_o,'fro')^2 + norm(u_o{1},'fro')^2+norm(u_o{2},'fro')^2));
end
time_FBHFPD = toc;
SNR_FBHFPD = - 20*log10(norm(zz - x,2)/norm(zz,2));
xxx = L(x);
fo_FBHFPD = lam3*norm(K(x)-b,2)^2/2+lam1*sum(sum(abs(xxx{1})))+lam1*sum(sum(abs(xxx{2})))+huberf(wav(x),lam2,delta);
errorFBHFPD= error_it;

x_FBHFPD = x;