clc; 
clear all;
close all;

%Original Image
z=imread('saturn.tif'); %128 pixels image
%z=imread('circular.tif'); %256 pixels image
z=double(z)./max(double(z(:)));
zz=z;

%% Blur
H=fspecial('gaussian',9,4);

%% Blur operator
[P,center]=psfGauss([9,9],4);
[m,n]=size(z);
Pbig=padPSF(P,[m,n]);

trans=@(X)dct2(X);
itrans=@(X)idct2(X);

e1=zeros(m,n);
e1(1,1)=1;
Sbig=dct2(dctshift(Pbig,center))./dct2(e1);


%Linear operator
L=@(X)Ltransold(X);
LT=@(P)Lforwardold(P);

%D = nabla d
K =@(X) itrans( Sbig .* trans(X) ) ; 
KA=@(X) itrans( conj(Sbig .* trans(X) )) ; 
    
% Blurred image
    b=K(zz);
% Noise
    randn('seed',314);
    b=imnoise(b,'gaussian',0,1e-3);


%%parameters
lam1 = 1e-1; % Norm 1
lam2 = 1e-3; % Huber function
lam3 = 1; % Norm 2 (in the article is 1)
delta = 1e-2; %Huber function

%
Kb = KA(b);
Sbig2 = Sbig.*Sbig;
D = @(X)  lam3*(KA(K(X))-Kb);

%C wavelets
wav=@(X)wavelet('2D haar',3,X);
iwav=@(X)wavelet('2D haar',-3,X);
C = @(x) lam2*iwav(grad_Huber(wav(x),delta));


% Lipshitz, cocercive and norm Constants
nL=sqrt(8);
zeta = lam2/delta;
beta = 1/(lam3*max(max(abs(Sbig).^2))); % norma de K^2 

% tolerance
tol = 1e-6;

% stepsizes

% step-sizes for Section 6.2
tau_FPDHF = 0.5;
tau_PDBTR = 0.5;

% step-sizes for Section 6.3, in this case delta must be changed to 1e-4
%tau_FPDHF = (-1/(2*beta)+sqrt(1/(4*beta^2)+4*zeta^2))/(2*zeta^2).*0.95;
%tau_PDBTR =  1/(2*zeta+1/(2*beta)).*0.95;


%% %%%% FPDHF

%stepsizes
t = tau_FPDHF;
epsilon = t/(2*beta);
s = 0.9999*(1-epsilon-t^2*zeta^2)/(t*nL^2);

% 
errorFPDHF=[];
fo_FPDHF=[];
SNR_FPDHF=[];

% initialization
error=1;
lam1s=lam1/s;
x = b;
u{1}=zeros(m-1,n);
u{2}=zeros(m,n-1);
nit=0;
j=1;
errorFPDHF(j) = 0.1;

while errorFPDHF(j) > tol
    j=j+1;
        x_o=x;
        u_o=u;       
        p = C(x_o);

        z_= x_o - t*( LT(u_o) + p + D(x_o) );
        z = min(max(0,z_),1);
    
        q = t*(C(z)-p);

        uu = L( 2*z-x_o-q );
        
        u1 = (u_o{1}+s*uu{1})./s;
        prox = sign(u1) .* max(0, abs(u1) - lam1s);
        u{1} = (u1-prox)*s;
        

        u2 = (u_o{2}+s*uu{2})./s;
        prox = sign(u2) .* max(0, abs(u2) - lam1s);
        u{2} = (u2-prox)*s;
        
        x = z - q;
        
        SNR_FPDHF(j) = - 20*log10(norm(zz - x,2)/norm(zz,2));
        xxx = L(x);
        fo_FPDHF(j) = lam3*norm(K(x)-b,2)^2/2+lam1*sum(sum(abs(xxx{1})))+lam1*sum(sum(abs(xxx{2})))+huberf(wav(x),lam2,delta);
        errorFPDHF(j)= sqrt((norm(x-x_o,'fro')^2+norm(u{1}-u_o{1},'fro')^2+norm(u{2}-u_o{2},'fro')^2) /(norm(x_o,'fro')^2 + norm(u_o{1},'fro')^2+norm(u_o{2},'fro')^2));
end
x_FPDHF=x;


%% %%%% FBHFPD



%stepsizes
t = tau_FPDHF;
th = 1;
rhomin = 1/(4*beta)+sqrt(1/(16*beta^2)+(zeta+(1-th)*nL/2)^2);
syms XX
eqn =  (XX+t-sqrt((XX-t)^2+XX^2*t^2*(1+th)^2*nL^2))/(2*XX*t)-rhomin == 0;
s = vpasolve(eqn,XX);
if  isempty(s);
    msg = 'invalid tau.';
    error(msg)
end

index = find(s == min(s(s>0)));
s = s(index);
clear XX
s= 0.999*double(s);
M = 1/min(t,s)+(1+th)*nL/2;
lambda = 0.99/M;
lam1s=lam1/s;


iter_FBHFPD = 0;

% initialization
x = b;
u{1}=zeros(m-1,n);
u{2}=zeros(m,n-1);
j=1;
errorFBHFPD(j) = 0.1;
 
 while errorFBHFPD(j) > tol
        j=j+1;
     x_o = x;
    u_o = u;

    c2x = C(x_o);
    y_  = x_o-t*(D(x_o)+c2x+LT(u_o));
    y = min(max(0,y_),1);

    vv = L(y+th*(y-x_o));

    v1 = (u_o{1}+s*vv{1})./s;
    prox = sign(v1) .* max(0, abs(v1) - lam1s);
    v_u{1} = (v1-prox)*s;

    v2 = (u_o{2}+s*vv{2})/s;
    prox = sign(v2) .* max(0, abs(v2) - lam1s);
    v_u{2} = (v2-prox)*s;

    uv{1} = u_o{1}-v_u{1};
    uv{2} = u_o{2}-v_u{2};
    x = x_o + lambda*(y-x_o+t*(c2x-C(y)+LT(uv)))./t;

    vv = L(y-x_o);
    u{1} = u_o{1} + lambda*(v_u{1}-u{1}-s*th*vv{1})./s;
    u{2} = u_o{2} + lambda*(v_u{2}-u{2}-s*th*vv{2})./s;

    SNR_FBHFPD(j) = - 20*log10(norm(zz - x,2)/norm(zz,2));
    xxx = L(x);
    fo_FBHFPD(j) = lam3*norm(K(x)-b,2)^2/2+lam1*sum(sum(abs(xxx{1})))+lam1*sum(sum(abs(xxx{2})))+huberf(wav(x),lam2,delta);
    errorFBHFPD(j)= sqrt((norm(x-x_o,'fro')^2+norm(u{1}-u_o{1},'fro')^2+norm(u{2}-u_o{2},'fro')^2) /(norm(x_o,'fro')^2 + norm(u_o{1},'fro')^2+norm(u_o{2},'fro')^2));
 end
x_FBHFPD = x;



%% %%%% PDBTR

% Lambda_n
lamk = 2;
lamk_ = 2;

% step-size
t1 =  tau_PDBTR;
s1 = 0.9999*(1-t1*(2*zeta+1/(2*beta)))/(t1*nL^2);
t11=t1;
s11=s1;

%
errorPDBTR=[];
fo_PDBTR=[];
SNR_PDBTR=[];

% initialization
x = b;
x_o = x;
c2x =  C(x);
u{1}=zeros(m-1,n);
u{2}=zeros(m,n-1);
z=u;
j=1;
errorPDBTR(j) = 0.1;
    
while errorPDBTR(j) > tol
    j=j+1;
    x_a = x_o;
    x_o = x;
    u_o = u;
    c2x_ = c2x;

    c2x = C(x_o);
    y_  = x_o-t1*(LT(u_o)+2*c2x-c2x_+D(x_o));
    x = min(max(0,y_),1);


    v = lamk*(x-x_o);

    vv = L(x_o+v);

    u1 = (u_o{1}+s1*vv{1})/s1;
    prox = sign(u1) .* max(0, abs(u1) - lam1/s1);
    u{1} = (u1-prox)*s1;

    u2 = (u_o{2}+s1*vv{2})/s1;
    prox = sign(u2) .* max(0, abs(u2) - lam1/s1);
    u{2} = (u2-prox)*s1;


    SNR_PDBTR(j) = - 20*log10(norm(zz - x,2)/norm(zz,2));
    xxx = L(x);
    fo_PDBTR(j) = lam3*norm(K(x)-b,2)^2/2+lam1*sum(sum(abs(xxx{1})))+lam1*sum(sum(abs(xxx{2})))+huberf(wav(x),lam2,delta);
    errorPDBTR(j)= sqrt((norm(x-x_o,'fro')^2+norm(u{1}-u_o{1},'fro')^2+norm(u{2}-u_o{2},'fro')^2) /(norm(x_o,'fro')^2 + norm(u_o{1},'fro')^2+norm(u_o{2},'fro')^2));
end

x_PDBTR = x;


%% %%%% PDRCK

%step-size
t1 =  tau_PDBTR;
s1 = 0.9999*(1-t1*(2*zeta+1/(2*beta)))/(2*t1*nL^2);

% initialization
errorPDRCK=[];
fo_PDRCK=[];
SNR_PDRCK=[];       
x = b;
x_o = x;
c2x =  C(x);
u{1}=zeros(m-1,n);
u{2}=zeros(m,n-1);
j=1;
errorPDRCK(j) = 0.1;
    
while errorPDRCK(j) > tol;
    j=j+1;
    x_a = x_o;
    x_o = x;
    u_o = u;
    z_o = z;
    c2x_ = c2x;
    
    z_ = L(x_o);
    u1 = (u_o{1}+s1*vv{1})/s1;
    prox = sign(u1) .* max(0, abs(u1) - lam1/s1);
    z{1} = (u1-prox)*s1;

    u2 = (u_o{2}+s1*vv{2})/s1;
    prox = sign(u2) .* max(0, abs(u2) - lam1/s1);
    z{2} = (u2-prox)*s1;


    c2x = C(x_o);
    uuu{1} = u_o{1}+z{1}-z_o{1};
    uuu{2} = u_o{2}+z{2}-z_o{2};
    y_  = x_o-t1*(LT(uuu)+2*c2x-c2x_+D(x_o));
    x = min(max(0,y_),1);


    vv = L(x);

    u1 = (u_o{1}+s1*vv{1})/s1;
    prox = sign(u1) .* max(0, abs(u1) - lam1/s1);
    u{1} = (u1-prox)*s1;

    u2 = (u_o{2}+s1*vv{2})/s1;
    prox = sign(u2) .* max(0, abs(u2) - lam1/s1);
    u{2} = (u2-prox)*s1;

    SNR_PDRCK(j) = - 20*log10(norm(zz - x,2)/norm(zz,2));
    xxx = L(x);
    fo_PDRCK(j) = lam3*norm(K(x)-b,2)^2/2+lam1*sum(sum(abs(xxx{1})))+lam1*sum(sum(abs(xxx{2})))+huberf(wav(x),lam2,delta);
    errorPDRCK(j)= sqrt((norm(x-x_o,'fro')^2+norm(u{1}-u_o{1},'fro')^2+norm(u{2}-u_o{2},'fro')^2) /(norm(x_o,'fro')^2 + norm(u_o{1},'fro')^2+norm(u_o{2},'fro')^2));
end
x_PDRCK = x;



figure(1)
imshow(zz);

figure(2)
imshow(b);

figure(3)
imshow(x_FPDHF);

figure(4)
imshow(x_FBHFPD);

figure(5)
imshow(x_PDBTR);

figure(6)
imshow(x_PDRCK);


figure(7)
axes('FontSize', 14);
hold on
loglog(errorFPDHF,'LineWidth',2)
plot(errorFBHFPD,'-.','LineWidth',2)
plot(errorPDBTR,'--','LineWidth',2)
plot(errorPDRCK,':','LineWidth',2)
grid on
grid minor
ylabel('Relative Error','FontSize', 18)
xlabel('Iteration number','FontSize', 18)
legend('FPDHF','FBHFPD','PDBTR','PDRCK','FontSize', 13)
set(gca,'yscale','log')

