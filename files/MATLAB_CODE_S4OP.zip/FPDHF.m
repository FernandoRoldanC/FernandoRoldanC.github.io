function      [time_FPDHF,SNR_FPDHF,fo_FPDHF,x_FPDHF,errorFPDHF,iter_FPDHF]=FPDHF(zz,Sbig,lam1,lam2,lam3,delta,b,tol,wavlev,t)
[m,n]=size(zz);
    %Linear operator
    L=@(X)Ltransold(X);
    LT=@(P)Lforwardold(P);
    

    %D = nabla d
    trans=@(X)dct2(X);
    itrans=@(X)idct2(X);
    K =@(X) itrans( Sbig .* trans(X) ) ; 
    KA=@(X) itrans( conj(Sbig .* trans(X) )) ; 

    %
    Kb = KA(b);
    Sbig2 = Sbig.*Sbig;
    D = @(X)  lam3*(KA(K(X))-Kb);
    
    %C wavelets
    wav=@(X)wavelet('2D haar',wavlev,X);
    iwav=@(X)wavelet('2D haar',-wavlev,X);
    C = @(x) lam2*iwav(grad_Huber(wav(x),delta));

    nL=sqrt(8);
    zeta = lam2/delta;
    beta = 1/(lam3*max(max(abs(Sbig).^2)));

    s = 0.9999*(1-t/(2*beta)-t^2*zeta^2)/(t*nL^2);

    if  s<=0;
        msg = 'invalid tau.';
        error(msg)
    end

    lam1s=lam1/s;
    
    x = b;
    u{1}=zeros(m-1,n);
    u{2}=zeros(m,n-1);
    iter_FPDHF = 0;
    error_it=1;
    tic
    % j = 1:niter
    while error_it > tol;
            iter_FPDHF=iter_FPDHF+1;
            x_o=x;
            u_o=u;       
            p = C(x_o);
    
            z_= x_o - t*( LT(u_o) + p + D(x_o) );
            z = min(max(0,z_),1);
        
            q = t*(C(z)-p);
    
            uu = L( 2*z-x_o-q );
            
            u1 = (u_o{1}+s*uu{1})./s;
            prox = sign(u1) .* max(0, abs(u1) - lam1s);
            u{1} = (u1-prox)*s;
            
    
            u2 = (u_o{2}+s*uu{2})./s;
            prox = sign(u2) .* max(0, abs(u2) - lam1s);
            u{2} = (u2-prox)*s;
            
            x = z - q;

           error_it= sqrt((norm(x-x_o,'fro')^2+norm(u{1}-u_o{1},'fro')^2+norm(u{2}-u_o{2},'fro')^2) /(norm(x_o,'fro')^2 + norm(u_o{1},'fro')^2+norm(u_o{2},'fro')^2));

            
    end
    time_FPDHF=toc;
    SNR_FPDHF = - 20*log10(norm(zz - x,2)/norm(zz,2));
    xxx = L(x);
    fo_FPDHF = lam3*norm(K(x)-b,2)^2/2+lam1*sum(sum(abs(xxx{1})))+lam1*sum(sum(abs(xxx{2})))+huberf(wav(x),lam2,delta);
    errorFPDHF= error_it;
    x_FPDHF=x;